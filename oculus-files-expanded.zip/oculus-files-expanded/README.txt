OCULUS FILES expanded local prototype
Open index.html in a browser. Original homepage CSS and layout retained.
Map tiles and Leaflet need internet access.
Profiles, drafts, notes, evidence and timeline proposals are stored only in localStorage. No real accounts, shared database, or moderation backend exist.
Official sensitive case tips must be sent to law enforcement, not to this prototype.
